<?php
/* 
 * @author Skitsanos
 */
require_once '../Vzaar.php';

/**
 * This API call returns the user's public details along with it's relevant metadata
 */
var_dump(Vzaar::getUserDetails('skitsanos'));
?>
